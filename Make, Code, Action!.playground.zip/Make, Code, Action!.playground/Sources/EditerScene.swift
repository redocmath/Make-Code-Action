// this is the code of editerScene

import SpriteKit
import UIKit

open class EditerScene: SKScene {
    
    let block_standard = 128    // block width standard
    var isPlayBGM = false
    
    public var bg: SKSpriteNode! // background
    public var player: SKSpriteNode!   // player
    public var completeAlert: SKSpriteNode!    // completeAlert
    public var console: SKSpriteNode!  // console Background
    public var finish: SKSpriteNode!   // finish position
    public var customBlock: SKSpriteNode!  // customBlock (D)
    public var start: SKSpriteNode!    // start position
    public var addBlockAlert: SKSpriteNode!    // add block alert
    public var delBlockAlert: SKSpriteNode!    // del block alert
    public var changeBlockAlert: SKSpriteNode!    // change block alert
    public var settingAlert: SKSpriteNode! // project setting alert
    public var breakBeat: SKSpriteNode!    // breakBeat radio
    public var crazyDuck: SKSpriteNode!    // crazyDuck radio
    public var dingDangDong: SKSpriteNode!    // ding dang dong radio
    public var bg1: SKSpriteNode! // bg1 radio
    public var bg2: SKSpriteNode! // bg2 radio
        
    public var console_text: SKLabelNode!  // console text
    public var info = "Click button to write code."    // information
    public var inputStatue = false // didn't write code = false, wrote = true
    public var vector = 2  // 0: left, 1: right, 2: up
    
    var backgroundMusic: SKAudioNode!
    
    // editing map
    public var additionMode = false
    public var whatblockAdd: Int!  // 0: grass, 1: stone
    public var deleteMode = false
    public var plagMode = false
    public var finishMode = false
    public var settingMode = false
    
    open override func didMove(to view: SKView) {
        
        // load sprite from scene.sks
        bg = childNode(withName: "//bg") as? SKSpriteNode
        player = childNode(withName: "//player") as? SKSpriteNode
        finish = childNode(withName: "//Finish") as? SKSpriteNode
        start = childNode(withName: "//Start") as? SKSpriteNode
        completeAlert = childNode(withName: "//CompleteAlert") as? SKSpriteNode
        addBlockAlert = childNode(withName: "//addBlockAlert") as? SKSpriteNode
        delBlockAlert = childNode(withName: "//delBlockAlert") as? SKSpriteNode
        changeBlockAlert = childNode(withName: "//changeBlockAlert") as? SKSpriteNode
        settingAlert = childNode(withName: "//projectSettingAlert") as? SKSpriteNode
        
        breakBeat = childNode(withName: "//BreakBeat") as? SKSpriteNode
        crazyDuck = childNode(withName: "//CrazyDuck") as? SKSpriteNode
        dingDangDong = childNode(withName: "//DingDangDong") as? SKSpriteNode
        bg1 = childNode(withName: "//bg1") as? SKSpriteNode
        bg2 = childNode(withName: "//bg2") as? SKSpriteNode
        
        // console_text setting
        console_text = SKLabelNode()
        console_text.text = self.info
        console_text.color = .black
        console_text.fontName = "Helvetica Neue Bold"
        console_text.verticalAlignmentMode = .center
        console_text.horizontalAlignmentMode = .center
        console_text.preferredMaxLayoutWidth = 400
        console_text.position = CGPoint(x: player.position.x, y: player.position.y + 130)
        console_text.fontSize = CGFloat(25)
        console_text.preferredMaxLayoutWidth = 200
        console_text.numberOfLines = 3
        
        // console background setting
        console = SKSpriteNode(imageNamed: "console")
        console.position = CGPoint(x: player.position.x, y: player.position.y + 130)
        
        // custom block setting
        customBlock = SKSpriteNode(texture: SKTexture(imageNamed: "grass_block_s"))
        customBlock.position = CGPoint(x: 10000, y: 10000)
        customBlock.zPosition = -1
        customBlock.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: customBlock.size.width, height: self.customBlock.size.height))
        customBlock.physicsBody?.affectedByGravity = false
        customBlock.physicsBody?.isDynamic = false
        customBlock.physicsBody?.pinned = false
        customBlock.physicsBody?.allowsRotation = false
        
        // add child
        addChild(customBlock)
        addChild(console)
        addChild(console_text)
    }
    
    open override func update(_ currentTime: TimeInterval) {
        
        // make console to follow player
        console.position = CGPoint(x: player.position.x, y: player.position.y + 130)
        console_text.position = CGPoint(x: player.position.x, y: player.position.y + 130)
        
    }
    
    // touch event
    open override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let location = touch.location(in: self)
            let touchNode = atPoint(location)
            
            // priority: cancel
            if touchNode.name == "cancel"{
                exit()
            }
            
            // priority: addBlockMode
            if self.additionMode {
                if self.whatblockAdd == 0 {
                    // custom block setting
                    let newBlock = SKSpriteNode(texture: SKTexture(imageNamed: "grass_block_s"))
                    newBlock.name = "newB"
                    newBlock.position = location
                    newBlock.zPosition = -1
                    newBlock.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: customBlock.size.width, height: self.customBlock.size.height))
                    newBlock.physicsBody?.affectedByGravity = false
                    newBlock.physicsBody?.isDynamic = false
                    newBlock.physicsBody?.pinned = false
                    newBlock.physicsBody?.allowsRotation = false
                    
                    addChild(newBlock)
                }
                else if self.whatblockAdd == 1 {
                    // custom block setting
                    let newBlock = SKSpriteNode(texture: SKTexture(imageNamed: "Stone_block"))
                    newBlock.name = "newB"
                    newBlock.position = location
                    newBlock.zPosition = -1
                    newBlock.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: customBlock.size.width, height: self.customBlock.size.height))
                    newBlock.physicsBody?.affectedByGravity = false
                    newBlock.physicsBody?.isDynamic = false
                    newBlock.physicsBody?.pinned = false
                    newBlock.physicsBody?.allowsRotation = false
                    
                    addChild(newBlock)
                }
            }
            
            // priority: delBlockMode
            else if self.deleteMode {
                if touchNode.name == "newB" {
                    touchNode.removeFromParent()
                }
            }
            
            // priority: plagMode
            else if self.plagMode {
                self.start.position = location
            }
            
            // priority: finishMode
            else if self.finishMode {
                self.finish.position = location
            }
            
            // clicked R
            if touchNode.name == "R_btn" {
                if self.console_text.text!.count > 20 && self.inputStatue {
                    
                } else if self.inputStatue {
                    self.console_text.text! += "R"
                }else{
                    self.console_text.text! = "R"
                    self.inputStatue = true
                }
            }
            
            // clicked L
            else if touchNode.name == "L_btn" {
                if self.console_text.text!.count > 20 && self.inputStatue {
                    
                } else if self.inputStatue {
                    self.console_text.text! += "L"
                }else{
                    self.console_text.text = "L"
                    self.inputStatue = true
                }
            }
            
            // clicked U
            else if touchNode.name == "U_btn" {
                
                if self.console_text.text!.count > 20 && self.inputStatue {
                    
                } else if self.inputStatue {
                    self.console_text.text! += "U"
                }else{
                    self.console_text.text = "U"
                    self.inputStatue = true
                }
            }
            
            // clicked P
            else if touchNode.name == "P_btn" {
                
                if self.console_text.text!.count > 20 && self.inputStatue {
                    
                } else if self.inputStatue {
                    self.console_text.text! += "P"
                }else{
                    self.console_text.text = "P"
                    self.inputStatue = true
                }
            }
            
            // Action start
            else if touchNode.name == "Action" {
                player.position = self.start.position
                action_player()
            }
            
            // Reset
            else if touchNode.name == "Reset" {
                player.run(SKAction.move(to: self.start.position, duration: 0))
                self.console_text.text = ""
                self.vector = 2
            }
            
            // Stop
            else if touchNode.name == "Stop" {
                self.player.removeAllActions()
                failed()
            }
            
            // Add grass
            else if touchNode.name == "AddGrass" {
                exit()
                self.additionMode = true
                self.whatblockAdd = 0
                self.addBlockAlert.run(SKAction.move(to: CGPoint(x: 0, y: 185), duration: 0.5))
            }
            
            // Add stone
            else if touchNode.name == "AddStone" {
                exit()
                self.additionMode = true
                self.whatblockAdd = 1
                self.addBlockAlert.run(SKAction.move(to: CGPoint(x: 0, y: 185), duration: 0.5))
            }
            
            // Del block
            else if touchNode.name == "DelBlock" {
                exit()
                self.deleteMode = true
                self.delBlockAlert.run(SKAction.move(to: CGPoint(x: 0, y: 185), duration: 0.5))
            }
            
            // plag
            else if touchNode.name == "Start" {
                exit()
                if !plagMode {
                    self.plagMode = true
                    self.changeBlockAlert.run(SKAction.move(to: CGPoint(x: 0, y: 185), duration: 0.5))
                }
            }
            
            // finish
            else if touchNode.name == "Finish" {
                exit()
                if !finishMode {
                    self.finishMode = true
                    self.changeBlockAlert.run(SKAction.move(to: CGPoint(x: 0, y: 185), duration: 0.5))
                }
            }
            
            // OneMoreTime
            else if touchNode.name == "OneMoreTime" {
                self.completeAlert.run(SKAction.move(to: CGPoint(x: 1024.961, y: 204.004), duration: 0.5))
                failed()
            }
            
            // playerToStart
            else if touchNode.name == "playerToStart" {
                player.position = self.start.position
            }
            
            // project setting
            else if touchNode.name == "Setting" {
                exit()
                self.settingAlert.run(SKAction.move(to: CGPoint(x: 0, y: 0), duration: 0.5))
                settingMode = true
            }
            
            // bgm: Break Beat
            else if touchNode.name == "BreakBeat" {
                breakBeat.texture = SKTexture(imageNamed: "Radio_selected")
                crazyDuck.texture = SKTexture(imageNamed: "Radio_unselected")
                dingDangDong.texture = SKTexture(imageNamed: "Radio_unselected")
                if let musicURL = Bundle.main.url(forResource: "breakbeat", withExtension: "mp3") {
                    if isPlayBGM {
                        removeChildren(in: [backgroundMusic])
                    }else{
                        isPlayBGM = true
                    }
                    backgroundMusic = SKAudioNode(url: musicURL)
                    addChild(backgroundMusic)
                }
            }
            
            // bgm: Crazy Duck
            else if touchNode.name == "CrazyDuck" {
                breakBeat.texture = SKTexture(imageNamed: "Radio_unselected")
                crazyDuck.texture = SKTexture(imageNamed: "Radio_selected")
                dingDangDong.texture = SKTexture(imageNamed: "Radio_unselected")
                if let musicURL = Bundle.main.url(forResource: "crazyduck", withExtension: "mp3") {
                    if isPlayBGM {
                        removeChildren(in: [backgroundMusic])
                    }else{
                        isPlayBGM = true
                    }
                    backgroundMusic = SKAudioNode(url: musicURL)
                    addChild(backgroundMusic)
                }
            }
            
            // bgm: Ding Dang Dong
            else if touchNode.name == "DingDangDong" {
                breakBeat.texture = SKTexture(imageNamed: "Radio_unselected")
                crazyDuck.texture = SKTexture(imageNamed: "Radio_unselected")
                dingDangDong.texture = SKTexture(imageNamed: "Radio_selected")
                if let musicURL = Bundle.main.url(forResource: "dingdangdong", withExtension: "mp3") {
                    if isPlayBGM {
                        removeChildren(in: [backgroundMusic])
                    }else{
                        isPlayBGM = true
                    }
                    backgroundMusic = SKAudioNode(url: musicURL)
                    addChild(backgroundMusic)
                }
            }
            
            // bg: bg1
            else if touchNode.name == "bg1" {
                bg1.texture = SKTexture(imageNamed: "Radio_selected")
                bg2.texture = SKTexture(imageNamed: "Radio_unselected")
                
                bg.texture = SKTexture(imageNamed: "bg1")
            }
            
            // bg: bg2
            else if touchNode.name == "bg2" {
                bg1.texture = SKTexture(imageNamed: "Radio_unselected")
                bg2.texture = SKTexture(imageNamed: "Radio_selected")
                
                bg.texture = SKTexture(imageNamed: "bg2")
            }
        }
    }
    
    func action_player() {
        
        // make actionlist
        var action_list = [SKAction]()
        
        // parse
        for code in self.console_text.text! {
            if code == "R" {    // Right
                let action = SKAction.moveBy(x: CGFloat(block_standard), y: 0, duration: 1.0)
                action.timingMode = .easeInEaseOut
                action_list.append(action)
                self.vector = 1
            }
            if code == "L" {    // Left
                let action = SKAction.moveBy(x: CGFloat(-block_standard), y: 0, duration: 1.0)
                action.timingMode = .easeInEaseOut
                action_list.append(action)
                self.vector = 0
            }
            if code == "U" {    // Up
                if vector == 1 {    // vector is right
                    let action = SKAction.moveBy(x: CGFloat(2 * block_standard), y: CGFloat(block_standard), duration: 0.5)
                    action.timingMode = .easeInEaseOut
                    action_list.append(action)
                }else if vector == 0{ // vector is left
                    let action = SKAction.moveBy(x: CGFloat(-2 * block_standard), y: CGFloat(block_standard), duration: 0.5)
                    action.timingMode = .easeInEaseOut
                    action_list.append(action)
                }else{  // vector is up (not moved left and right)
                    let action = SKAction.moveBy(x: 0, y: CGFloat(2 * block_standard), duration: 1)
                    action.timingMode = .easeInEaseOut
                    action_list.append(action)
                }
            }
            if code == "P" {    // make new custom block
                let action = SKAction.customAction(withDuration: 1) { (node, elapsetime) in
                    if elapsetime == CGFloat(1.0) {
                        self.player.position.y += CGFloat(self.block_standard * 2)
                        self.customBlock.position = CGPoint(x: self.player.position.x, y: self.player.position.y - CGFloat(self.block_standard) * 2)
                    }
                }
                action_list.append(action)
            }
        }
        
        // action sequence to do
        let action_todo = SKAction.sequence(action_list)
        
        
        // run sequence
        player.run(action_todo) {   // when it finished
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                if abs(self.player.position.x - self.finish.position.x) < 70 && abs(self.player.position.y - self.finish.position.y) < 70 {
                    // finish place
                    self.success()
                }else{
                    // wrong place
                    self.failed()
                }
            }
        }
    }
    
    func success() {    // success func
        self.vector = 2
        self.console_text.text = "You got it!"
        self.player.texture = SKTexture(imageNamed: "Charactor_Action_Suc")
        self.completeAlert.run(SKAction.move(to: CGPoint(x: 0, y: 0), duration: 0.5))
    }
    
    func failed() {     // failed func
        self.player.texture = SKTexture(imageNamed: "Charactor_Action_Fai")
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            self.vector = 2
            self.inputStatue = false
            self.player.run(SKAction.move(to: CGPoint(x: self.start.position.x, y: self.start.position.y), duration: 0.5))
            self.player.texture = SKTexture(imageNamed: "Charactor_Action_Main")
            self.customBlock.position = CGPoint(x: 10000, y: 10000)
        }
    }
    
    func exit() {
        self.addBlockAlert.run(SKAction.move(to: CGPoint(x: 3.277, y: 584.5), duration: 0.5))
        self.delBlockAlert.run(SKAction.move(to: CGPoint(x: 3.277, y: 584.5), duration: 0.5))
        self.settingAlert.run(SKAction.move(to: CGPoint(x: 1680, y: 204.004), duration: 0.5))
        self.changeBlockAlert.run(SKAction.move(to: CGPoint(x: 3.277, y: 584.5), duration: 0.5))
        
        self.additionMode = false
        self.deleteMode = false
        self.plagMode = false
        self.finishMode = false
        self.settingMode = false
        
        self.whatblockAdd = -1
    }
}
