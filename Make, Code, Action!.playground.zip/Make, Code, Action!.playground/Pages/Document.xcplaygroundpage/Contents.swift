/*:
 ![img](icon.png)
 # Document
 ## list
 - "Add Block"
 - "Change Start(Finish) point"
 - "Delete Block"
 - "How to make code"
 - "How to add bgm"
 - "How to add background Image"
 
 [back to editer](Editer)
 */

import Foundation

var searchWord = "Add Block"
print("\(search(key: searchWord))")
