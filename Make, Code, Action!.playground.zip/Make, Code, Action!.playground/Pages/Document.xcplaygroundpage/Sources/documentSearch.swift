import Foundation

public func search(key: String) -> String {
    switch key {
    case "Add Block":
        return """
            1. click addGrass button or addStone button to enter add block mode
            2. click where you want to create block
            3. if you finished, click 🅧.
        """
    case "Change Start(Finish) point":
        return """
            1. click start point(flag)
            2. click where you want to move flag
            3. if you finished, click 🅧.
        """
    case "Delete Block":
        return """
            1. click deleteBlock button
            2. click block that you want to remove
            3. if you finished, click 🅧.
        """
    case "How to make code":
        return """
            1. click controller button to write code
            2. if you want to clear code, click 🔄
            3. if you finished, run.
        """
    case "How to add bgm":
    return """
        1. click 🅢
        2. change it.
        3. then click 🅧
    """
    case "How to add background Image":
    return """
        1. click 🅢
        2. change it.
        3. then click 🅧
    """
    default:
        return "No Result"
    }
}
