/*:
 ![icon](icon.png)
 # Make, Code, Action!
 ### the easiest way to make Platform Game
 
 ---
 
 # Introduce 🚀
 Most children in the world like **game**🕹. And they always **pay attention** to game. I think you will now this fact.
 
 However, do you know *54% students like to make code* 🛠 (from [Code.org](https://code.org/promote))?
 
 That means **54% students want to make game**, and introucing their game to other people.
 
 this program, ***Make, Code, Action!*** let you to make platform game to click and click. Moreover, this program can teach you about `command` programming term as making a whole new ***Player Controller*** system.
 
  ---
 
 # OK, But How To Use? 🏁
 It is very simple, but powerful.
 
 1. ***Make*** the map
 
 ![help img](help_img01.png)
 
 2. ***Code***
 
 ![help img](help_img02.png)
 
 3. ***Action***
 
 If your character went to finish point, you clear your map!
 
 - Note:
  If you want to know more, click [Documention](Document) to get more
 
 ---
 
 # That's nice, but I want to add more! 🎹📷
 
 If you want to add bgm and background image, click 🅢 button to set project setting.
 
 ---
 
 # You win Swift Student Challenge! 🏆
 
 I hate COVID-19, and I think you too. I think Apple's Online WWDC 2020 is very good decision against COVID-19. See You in WWDC!
 
 ![help img](wwdc.jpg)
 
 ---
 
 ### 2020, Coder LoveMath(Coder)
 ### #MCA(MakeCodeAction)
 
 
 */
import PlaygroundSupport
import UIKit
import SpriteKit

// Load the SKScene from 'Scene.sks'
let sceneView = SKView(frame: CGRect(x:0, y:100 , width: 640, height: 480))
if let scene = EditerScene(fileNamed: "Scene") {
    // Set the scale mode to scale to fit the window
    scene.scaleMode = .aspectFill
    
    // Present the scene
    sceneView.presentScene(scene)
}

PlaygroundSupport.PlaygroundPage.current.liveView = sceneView

